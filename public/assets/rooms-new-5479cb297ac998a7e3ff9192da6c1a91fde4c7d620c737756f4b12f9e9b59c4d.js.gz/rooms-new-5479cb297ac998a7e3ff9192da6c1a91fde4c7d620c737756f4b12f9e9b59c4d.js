(function() {
  this.show_room_detail = function() {
    $('#item-setting').toggle();
  };

  this.show_profit_item_detail = function() {
    $('#profit-item').toggle();
  };

}).call(this);
